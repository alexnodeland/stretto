Flows behind docs/results/benchmarks-2026-09-27.md, learned with `stretto learn --results ... --habit-only`
from the older agents' runs of each benchmark's training tasks (see the page for which agents):

- bfcl.flow.json: BFCL v4 multi-turn base, 8 models' logged runs (BFCL-Result 2025-12-16).
- bfcl-ground-truth.flow.json: the same tasks' ground-truth trajectories.
- agentdojo-<suite>.flow.json: AgentDojo's benign runs, 11 models released before May 2024.
- workbench-<domain>.flow.json: WorkBench's 2026 runs, 10 models.
- dtap-customer_service-<source>.flow.json, dtap_crm-, dtap_telecom- and dtap_travel-<source>.flow.json:
  DTap-Bench's runs of four domains, learned from each agent's own training runs (own-<agent>), its
  harness's other agents (same-<agent>), the other harnesses' agents (other-<harness>), and all seven (all).
- mcpmark_<service>.flow.json: MCPMark's filesystem, PostgreSQL and GitHub runs, 8 older models (run 1).

τ-bench's replays use the τ²-bench flows published with docs/results/reach-2026-09-26.md.
